#ESERCITAZIONE W8D4 - Isabella Verrecchia
#Task1: Implemento fisicamente le tabelle create nel diagramma E-R
#Prima di tutto creo un database ToysGroup, nel quale inserire le entità, agli attributi e i record.
CREATE DATABASE toysgroup;
USE toysgroup;

#Adesso creo le mie tabelle, inserendo prima le entità forti e poi quelle deboli.

CREATE TABLE Category (
CategoryID INT AUTO_INCREMENT PRIMARY KEY,
CategoryName VARCHAR (50)
); 

CREATE TABLE Region (
RegionID INT AUTO_INCREMENT PRIMARY KEY,
RegionName VARCHAR(50)
);

CREATE TABLE Product (
ProductID INT AUTO_INCREMENT PRIMARY KEY,
ProductName VARCHAR(50),
CategoryID INT,
CONSTRAINT Fk_Category
FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);

CREATE TABLE Country(
CountryID INT AUTO_INCREMENT PRIMARY KEY,
CountryName VARCHAR(60),
RegionID INT,
CONSTRAINT Fk_Region
FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

CREATE TABLE Sales (
SalesID INT AUTO_INCREMENT PRIMARY KEY,
ProductID INT,
RegionID INT,
DateOrder DATE,
DateSales DATE,
OrderQuantity INT,
UnitPrice DECIMAL(7,2),
SalesAmount DECIMAL(7,2),
CONSTRAINT Fk_Regione
FOREIGN KEY (RegionID) REFERENCES Region(RegionID),
CONSTRAINT Fk_Product
FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

# Task3: Popolo le tabelle create con dummy data.

INSERT INTO Category (CategoryName) 
VALUES
	('Action Toys'),
	('Educational'),
	('Puzzle'),
	('Stuffed Animals'),
	('Outdoor Toys'),
	('Electronic Toys'),
	('Board Games'),
	('Construction Sets'),
	('Vehicles'),
	('Arts & Crafts');

SELECT * FROM Category;

INSERT INTO Region (RegionName) 
VALUES
	('Europe'),
	('Asia'),
	('America'),
	('Africa'),
	('Oceania'),
	('Middle East'),
	('Central America'),
	('South America');

INSERT INTO Product (ProductName, CategoryID) 
VALUES
('Super Robot', 1),
('Math Board', 2),
('Word Puzzle', 3),
('Teddy Bear', 4),
('Water Blaster', 5),
('RC Car', 6),
('Chess Set', 7),
('Lego City', 8),
('Toy Truck', 9),
('Coloring Kit', 10),
('Ninja Warrior', 1),
('ABC Blocks', 2),
('3D Puzzle Globe', 3),
('Bunny Plush', 4),
('Frisbee Set', 5),
('Drone Mini', 6),
('Snakes & Ladders', 7),
('Mega Builder', 8),
('Firetruck Toy', 9),
('Painting Set', 10);

INSERT INTO Country (CountryName, RegionID) 
VALUES
('Italy', 1),
('France', 1),
('Germany', 1),
('Spain', 1),
('United Kingdom', 1),
('China', 2),
('Japan', 2),
('India', 2),
('South Korea', 2),
('Indonesia', 2),
('USA', 3),
('Canada', 3),
('Mexico', 3),
('Brazil', 3),
('South Africa', 4),
('Nigeria', 4),
('Egypt', 4),
('Australia', 5),
('New Zealand', 5),
('United Arab Emirates', 6),
('Saudi Arabia', 6),
('Costa Rica', 7),
('Panama', 7),
('Argentina', 8),
('Chile', 8);

INSERT INTO Sales (ProductID, RegionID, DateOrder, DateSales, OrderQuantity, UnitPrice, SalesAmount) 
VALUES
(1, 1, '2024-01-10', '2024-01-15', 100, 10.00, 1000.00),
(2, 1, '2024-02-01', '2024-08-10', 50, 12.00, 600.00), 
(3, 2, '2024-03-12', '2024-03-13', 20, 15.00, 300.00),
(4, 3, '2024-04-20', '2024-11-10', 70, 9.50, 665.00), 
(5, 4, '2024-05-01', '2024-05-03', 40, 11.00, 440.00),
(6, 5, '2024-06-10', '2024-06-15', 60, 10.00, 600.00),
(7, 6, '2024-07-05', '2024-07-06', 30, 15.00, 450.00),
(8, 1, '2024-08-20', '2024-08-25', 80, 9.50, 760.00),
(9, 2, '2024-09-01', '2025-03-10', 90, 12.00, 1080.00), 
(10, 3, '2024-10-11', '2024-10-15', 55, 11.00, 605.00),
(1, 1, '2024-11-15', '2024-11-20', 25, 10.00, 250.00),
(2, 1, '2024-12-01', '2024-12-03', 22, 15.00, 330.00),
(3, 2, '2025-01-10', '2025-01-12', 40, 9.50, 380.00),
(4, 3, '2025-02-15', '2025-09-01', 35, 12.00, 420.00), 
(5, 4, '2025-03-20', '2025-03-21', 38, 11.00, 418.00),
(6, 5, '2025-04-10', '2025-04-11', 42, 10.00, 420.00),
(7, 6, '2025-05-05', '2025-05-10', 29, 15.00, 435.00),
(8, 7, '2025-06-01', '2025-06-02', 18, 12.00, 216.00),
(9, 8, '2025-06-03', '2025-06-04', 27, 9.50, 256.50),
(10, 8, '2025-06-05', '2025-06-06', 33, 11.00, 363.00),
(1, 1, '2025-06-10', '2025-06-11', 12, 10.00, 120.00),
(3, 2, '2025-06-12', '2025-06-15', 20, 15.00, 300.00),
(5, 4, '2025-06-13', '2025-06-14', 50, 11.00, 550.00),
(2, 1, '2025-06-15', '2025-06-20', 36, 12.00, 432.00),
(4, 3, '2025-06-21', '2025-06-25', 48, 9.50, 456.00),
(6, 5, '2025-06-26', '2025-06-27', 60, 10.00, 600.00),
(7, 6, '2025-06-28', '2025-06-29', 22, 15.00, 330.00),
(8, 7, '2025-06-30', '2025-07-01', 45, 9.50, 427.50),
(9, 8, '2025-07-02', '2025-07-03', 32, 12.00, 384.00),
(10, 8, '2025-07-04', '2025-07-05', 50, 11.00, 550.00);

#Task4: Inizio con le query richieste
#esercizio 1
#affinchè un campo sia chiave primaria sono necessarie due condizioni fondamentali: ogni record deve essere univoco e nn nullo.
#verifico che non ci siano valori nulli
SELECT COUNT(*) AS ValoriNulli
FROM Category
WHERE CategoryID IS NULL; #come risultato dà 0 valori nulli

#verifico che non ci siano valori ripetuti: con il seguente codice ho fatto un doppio conteggio delle chiavi per vedere se combacia
SELECT COUNT(DISTINCT CategoryID) AS ValoriDistintiChiave, COUNT(CategoryID) AS TotCategoryID
FROM Category; 

#ripeto le query per ogni tabella
SELECT COUNT(*) AS ValoriNulli
FROM Country
WHERE CountryID IS NULL; 
SELECT COUNT(DISTINCT CountryID) AS ValoriDistintiChiave, COUNT(CountryID) AS TotCountryID
FROM Country; 

SELECT COUNT(*) AS ValoriNulli
FROM Product
WHERE ProductID IS NULL; 
SELECT COUNT(DISTINCT ProductID) AS ValoriDistintiChiave, COUNT(ProductID) AS TotProductID
FROM Product;

SELECT COUNT(*) AS ValoriNulli
FROM Region
WHERE RegionID IS NULL; 
SELECT COUNT(DISTINCT RegionID) AS ValoriDistintiChiave, COUNT(RegionID) AS TotRegionID
FROM Region;

SELECT COUNT(*) AS ValoriNulli
FROM Sales
WHERE SalesID IS NULL; 
SELECT COUNT(DISTINCT SalesID) AS ValoriDistintiChiave, COUNT(SalesID) AS TotSalesID
FROM Sales;

#esercizio 2 ______________________________________________________________________________________________________________________________________
/* Per esporre in output tutti i campi richiesti è necessario fare diverse join tra le tabelle create, poichè i campi provengono dalle diverse tabelle.
Per inserire un valore booleano è sufficiente, dopo aver calcolato con la funzione datediff la differenza tra le due date (ordine e vendita), mettere l'operatore logico > che,
se soddisfa la condizione scritta resituisce 1, altrimenti 0.
*/ 

SELECT S.SalesID, S.DateSales, P.ProductName, C.CategoryName, R.RegionName, Co.CountryName,  DATEDIFF(DateSales,DateOrder) > 180 AS '1' #DATEDIFF(DateSales,DateOrder) <= 180 AS '0'
FROM Sales S
JOIN Product P ON S.ProductID=P.ProductID
JOIN Category C ON P.CategoryID=C.CategoryID
JOIN Region R ON S.RegionID=R.RegionID
JOIN Country Co ON Co.RegionID=R.RegionID
ORDER BY SalesID ASC
;
 
#ESERCIZIO 3 ______________________________________________________________________________________________________________________________________
# Per avere in output l'elenco dei prodotti con tot vendite > delle vendite medie dell'ultimo anno è necessario usare le subquery per suddividere la query principale, 
# poichè non è possibile riuscire con una sola query
 
#Prima di tutto estraggo l'anno dalla data
SELECT YEAR(DateSales) AS AnnoVendita
FROM Sales;

#Poichè dall'output ottenuto osservo che ho solo 2 anni (2024 e 2025), per avere un'analisi più "parlante", decido di cambiare qualche data ordine e data vendita
START TRANSACTION;
UPDATE Sales
SET DateOrder = '2023-01-01', DateSales = '2023-07-15'
WHERE SalesID IN (3, 5);
#ROLLBACK  #prima di fare commit ho lasciato il rollback nel caso in cui non avesse funzionato l'update
COMMIT;

START TRANSACTION;
UPDATE Sales
SET DateOrder = '2021-10-01', DateSales = '2021-11-20'
WHERE SalesID IN (10, 16);
#ROLLBACK;
COMMIT;

#Estraggo l'ultimo anno di vendita: ottengo come output 2025
SELECT MAX( YEAR(DateSales)) AS UltimoAnnoVendita
FROM Sales;

#Imposto prima la query più interna, per calcolare la media delle vendite per l'ultimo anno: ordinando per data decrescente e mettendo LIMIT=1, ottengo solo l'anno richiesto
SELECT AVG(SalesAmount) AS MediaVendite #YEAR(DateSales) AS AnnoVendite
FROM Sales
GROUP BY YEAR(DateSales)
ORDER BY YEAR(DateSales) DESC
LIMIT 1;

#Calcolo la query più esterna, facendo anche una join per avere in output il nome del prodotto. Con la condizione inserita nel where come subquery ottengo l'output richiesto
SELECT P.ProductID, P.ProductName, SUM(S.SalesAmount) AS TotVendite
FROM Sales S
JOIN Product P ON S.ProductID=P.ProductID
WHERE S.SalesAmount > (SELECT AVG(SalesAmount) AS MediaVendite #YEAR(DateSales) AS AnnoVendite
FROM Sales
GROUP BY YEAR(DateSales)
ORDER BY YEAR(DateSales) DESC
LIMIT 1)
GROUP BY P.ProductID;

#ESERCIZIO 4
#Per esporre l'elenco dei soli prodotti venduti è sufficiente prendere la tabella Sales (poichè se sono in sales vuol dire che sono venduti), effettuando poi una somma per anno del totale fatturato

SELECT ProductID, SUM(SalesAmount) AS TotFatturato, YEAR(DateSales) AS AnnoVendita
FROM Sales
GROUP BY ProductID, YEAR(DateSales)
ORDER BY AnnoVendita;

#ESERCIZIO 5 ____________________________________________________________________________________________________________________________________________________
#Per esporre il fatturato totale per stato per anno ho effettuato una join con la tabella Region e con la tabella Country, calcolando poi la somma delle vendite e
# ordinando il tutto per anno e fatturato decrescente
SELECT C.CountryName, SUM(S.SalesAmount) AS TotFatturato, YEAR(S.DateOrder) AS AnnoVendita
FROM Sales S
JOIN Region R ON S.RegionID=R.RegionID
JOIN Country C ON C.RegionID=R.RegionID
GROUP BY C.CountryName, YEAR(S.DateOrder)
ORDER BY AnnoVendita, TotFatturato;

#ESERCIZIO 6 ____________________________________________________________________________________________________________________________________________________________
# Per capire qual è la categoria più richiesta dal mercato ho effettuato prima le join tra Sales e Product e tra Product e Category. Successivamente ho calcolato la somma
# delle quantità, raggruppato per quantità e categoria e inserendo LIMIT=1 ottengo la categoria con Totale quantità maggiore. 

SELECT C.CategoryName, SUM(S.OrderQuantity) AS TotQuantita
FROM Sales S
JOIN Product P ON S.ProductID=P.ProductID
JOIN Category C ON P.CategoryID=C.CategoryID
GROUP BY S.OrderQuantity, C.CategoryName
ORDER BY TotQuantita DESC
LIMIT 1;

#ESERCIZIO 7 __________________________________________________________________________________________________________________________________________________________
#Per esporre i prodotti invenduti ho seguito i seguenti due approcci
#Primo approccio: utilizzo NOT IN con una subquery. 

#Prima faccio la query interna per selezionare tutti i prodotti in Sales
SELECT DISTINCT ProductID
FROM Sales;

#Poi la query esterna per selezionare i prodotti che sono in Product ma che non sono in Sales.
SELECT ProductID, ProductName 
FROM Product
WHERE ProductID NOT IN (SELECT ProductID
FROM Sales);

#Secondo approccio: utilizzo una left join tra Product e Sales. Con la left join ottengo valori NULL per i prodotti non venduti, perciò lo inserisco nella condizione della where 
#per avere in output solo quelli
SELECT P.ProductID, P.ProductName
FROM Product P
LEFT JOIN Sales S ON P.ProductID = S.ProductID
WHERE S.ProductID IS NULL;

#ESERCIZIO 8 _______________________________________________________________________________________________________________________________________________________________
# Creo una vista per avere le informazioni sui prodotti

CREATE VIEW Prodotti AS(
SELECT P.ProductID, P.ProductName, C.CategoryName
FROM Product P 
JOIN Category C ON P.CategoryID=C.CategoryID
ORDER BY ProductID);

#ESERCIZIO 9 ______________________________________________________________________________________________________________________________________________________________
#Creo una vista per le informazioni geografiche

CREATE VIEW AreaGeografica AS(
SELECT R.RegionID, R.RegionName, C.CountryName
FROM Region R
JOIN Country C ON C.RegionID=R.RegionID);
 



