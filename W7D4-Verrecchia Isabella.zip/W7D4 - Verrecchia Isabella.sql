#W7D4 -Verrecchia Isabella

#PUNTO 1
#Implementa una vista denominata Product al fine di creare unʼanagrafica (dimensione) prodotto completa. La vista, se interrogata o utilizzata 
#come sorgente dati, deve esporre il nome prodotto, il nome della sottocategoria associata e il nome della categoria associata.

CREATE VIEW Product AS(
SELECT D.ProductKey, D.EnglishProductName AS NomeProdotto, S.EnglishProductSubcategoryName AS NomeSottocategoriaProdotto, S.ProductSubcategoryKey AS CodiceSottocategoriaProdotto, 
C.EnglishProductCategoryName AS NomeCategoriaProdotto, C.ProductCategoryKey AS CodiceCategoriaProdotto
FROM dimproduct D 
JOIN dimproductsubcategory S ON D.ProductSubcategoryKey=S.ProductSubcategoryKey
JOIN dimproductcategory C ON S.ProductCategoryKey=C.ProductCategoryKey
);

SELECT * FROM Product;

#PUNTO 2
#Implementa una vista denominata Reseller al fine di creare unʼanagrafica (dimensione) reseller completa. La vista, se interrogata o utilizzata come sorgente dati, 
#deve esporre il nome del reseller, il nome della città e il nome della regione.

CREATE VIEW Reseller AS(
SELECT R.ResellerKey, R.ResellerName AS NomeReseller, G.City AS NomeCitta, G.StateProvinceName AS NomeRegione, G.GeographyKey
FROM dimreseller R
JOIN dimgeography G ON G.GeographyKey=R.GeographyKey
);

SELECT * FROM Reseller;

#PUNTO 3
#Crea una vista denominata Sales che deve restituire la data dellʼordine, il codice documento, la riga di corpo del documento, la quantità venduta, 
#lʼimporto totale e il profitto.

CREATE VIEW Sales AS(
SELECT D.ProductKey, F.ResellerKey, F.OrderDate AS DataOrdine, F.SalesOrderNumber AS CodiceDocumento, F.SalesOrderLineNumber AS RigaCorpoDocumento, 
F.OrderQuantity AS QuantitaVenduta, F.SalesAmount AS ImportoTotale, F.SalesAmount-F.TotalProductCost AS Profitto
FROM factresellersales F
JOIN dimproduct D ON F.ProductKey=D.ProductKey
);

SELECT * FROM Sales;

#DROP VIEW product;
#DROP VIEW reseller;
#DROP VIEW sales;


